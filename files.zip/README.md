# Ramp Rats

Build your own skate park, then skate it in 3D. Runs entirely in the browser with [three.js](https://threejs.org/), no build step and no install.

## Play

Open the GitHub Pages site for this repo (see "Deploy" below), or open `index.html` in a browser. It needs an internet connection because three.js loads from cdnjs.

## Controls

**Build mode**
- Click to place a ramp, drag to orbit, scroll to zoom
- W A S D to pan, R to rotate 90 degrees, Q and E to rotate 15 degrees
- 1 to 4 pick Kicker, Quarter, Funbox or Erase
- Enter switches to skate mode

**Skate mode**
- W push, S brake, A and D steer, Space ollie, hold N or Shift for a nollie
- In the air: J kickflip, L heelflip, K shove-it, I impossible. Press them together for combos such as tre flip (J+K), laser flip (L+K) or hardflip (I+J)
- Hold A or D in the air to spin
- R respawn, Enter back to build mode

**Style menu** (button at the top, or M): change board shape, deck and wheel colors, character, ground, and ramp surface. Your choices and your park layout are saved in your browser.

## Deploy on GitHub Pages

1. Push these files to a GitHub repository.
2. In the repo, go to Settings, then Pages.
3. Under Build and deployment, choose "Deploy from a branch", pick `main` and `/ (root)`, then Save.
4. After a minute the site is live at `https://YOUR-USERNAME.github.io/REPO-NAME/`.

## Credits

Built with [three.js](https://threejs.org/) (MIT license).
